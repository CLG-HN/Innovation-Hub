// csl.js
// Real Citation Style Language (CSL) formatting, via the bundled
// citeproc-js engine (vendor/citeproc.js) plus four bundled styles
// (vendor/styles/{apa,mla,chicago,ieee}.csl) and the en-US locale
// (vendor/locales/locales-en-US.xml). Used by:
//   - cite.js (content script, <all_urls>) — the "Cite" popover
//   - collection.js / popup.js (extension pages) — Collections export
//
// Deliberately NOT loaded by background.js. citeproc-js needs a real
// `DOMParser` to parse style/locale XML (see vendor/citeproc.js — it falls
// back to ActiveXObject/XMLHttpRequest shims if DOMParser is missing, none
// of which exist in an MV3 service worker either), so all CSL formatting
// happens in a DOM context. background.js only ever hands back structured,
// unformatted metadata (title/authors/year/venue/doi/url) — see
// background.js's toResultShape() — and formatting happens here instead.
//
// Every public function in this file is safe to call speculatively: a
// missing bundled file, a malformed CSL-JSON item, or citeproc-js itself
// throwing internally all surface as a rejected promise, never an
// uncaught exception — so a citation-formatting failure can never cascade
// into breaking whatever page loaded this script (the same isolation
// lesson from the Collections recommendations fix).

const LENS81_CSL_STYLES = {
  apa: { file: 'vendor/styles/apa.csl', label: 'APA' },
  mla: { file: 'vendor/styles/mla.csl', label: 'MLA' },
  chicago: { file: 'vendor/styles/chicago.csl', label: 'Chicago' },
  ieee: { file: 'vendor/styles/ieee.csl', label: 'IEEE' },
};
const LENS81_CSL_LOCALE_FILE = 'vendor/locales/locales-en-US.xml';
const LENS81_CSL_DEFAULT_LOCALE = 'en-US';

// True only if vendor/citeproc.js loaded successfully before this file did
// (both are listed in that order everywhere this file is included). Lets
// callers check availability up front instead of waiting for a rejected
// promise on first use.
const LENS81_CSL_AVAILABLE = typeof CSL !== 'undefined';

const lens81CslStyleXmlCache = {};
let lens81CslLocaleXmlCache = null;
const lens81CslEngineCache = {};
let lens81CslItemStore = {}; // id -> CSL-JSON, populated right before each engine call

// All engine calls are serialized through this queue. citeproc-js pulls
// items via a synchronous sys.retrieveItem(id) callback that reads from
// the shared lens81CslItemStore below — without serializing, two
// formatting calls close together (e.g. two "Cite" popovers, or a
// popover open while a Collections export runs) could interleave between
// "await engine ready" and "set item store / call updateItems", corrupting
// each other's output. Formatting one citation is cheap, so queuing has no
// noticeable cost.
let lens81CslQueue = Promise.resolve();
function lens81CslEnqueue(task) {
  const run = lens81CslQueue.then(task, task);
  lens81CslQueue = run.then(
    () => {},
    () => {}
  );
  return run;
}

async function lens81CslFetchText(relativePath) {
  const res = await fetch(chrome.runtime.getURL(relativePath));
  if (!res.ok) throw new Error(`Lens⁸¹ CSL: could not load ${relativePath} (HTTP ${res.status})`);
  return res.text();
}

async function lens81GetCslEngine(styleKey) {
  const meta = LENS81_CSL_STYLES[styleKey];
  if (!meta) throw new Error(`Lens⁸¹ CSL: unknown citation style "${styleKey}"`);
  if (!LENS81_CSL_AVAILABLE) throw new Error('Lens⁸¹ CSL: citeproc-js did not load.');
  if (lens81CslEngineCache[styleKey]) return lens81CslEngineCache[styleKey];

  if (!lens81CslStyleXmlCache[styleKey]) {
    lens81CslStyleXmlCache[styleKey] = await lens81CslFetchText(meta.file);
  }
  if (!lens81CslLocaleXmlCache) {
    lens81CslLocaleXmlCache = await lens81CslFetchText(LENS81_CSL_LOCALE_FILE);
  }

  const sys = {
    // Only en-US is bundled; every target style's own default-locale is
    // either en-US or unset (which CSL itself falls back to en-US for),
    // so a single fixed locale is returned regardless of what's asked for
    // rather than trying to fetch a locale that was never bundled.
    retrieveLocale: () => lens81CslLocaleXmlCache,
    retrieveItem: (id) => lens81CslItemStore[id],
  };

  const engine = new CSL.Engine(sys, lens81CslStyleXmlCache[styleKey], LENS81_CSL_DEFAULT_LOCALE);
  lens81CslEngineCache[styleKey] = engine;
  return engine;
}

// --- CSL-JSON conversion ----------------------------------------------------

// Splits a plain "First Middle Last" name into CSL's {given, family} shape
// using a last-space heuristic — the same level of approximation the
// hand-rolled formatters this replaces already used (see background.js's
// splitName()), just in citeproc's expected field names. This won't handle
// multi-word surnames or particles ("van der Berg") correctly, but neither
// did the code it replaces — citeproc-js still produces correctly *styled*
// output (proper inversion, initials, ampersands/commas per style) around
// whatever split it's given.
function lens81NameToCslPerson(fullName) {
  const parts = (fullName || '').trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return null;
  if (parts.length === 1) return { family: parts[0] };
  return { given: parts.slice(0, -1).join(' '), family: parts[parts.length - 1] };
}

// Best-effort parse of a raw Google Scholar byline (e.g. "M Jinek, K
// Chylinski… - Science, 2012 - science.org") into structured
// author/venue/year. Used only for papers saved from a Scholar result,
// which never had these fields separated out to begin with — collections.js
// stores exactly what Scholar's byline line says, unparsed (see
// collections-content.js). This is inherently approximate: Scholar
// truncates long author lists with "…", and venue/year are read from
// whatever sits between the first and second " - ", which is usually but
// not always just "Journal, Year". It never fabricates a year or venue
// that wasn't legible in the byline — a wrong-shaped byline just yields
// fewer parsed fields, not a wrong value.
function lens81ParseScholarByline(byline) {
  const segments = (byline || '').split(' - ').map((s) => s.trim());
  const authorsPart = segments[0] || '';
  const venueYearPart = segments.length > 1 ? segments[1] : '';

  const authors = authorsPart
    .replace(/…$/, '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .map(lens81NameToCslPerson)
    .filter(Boolean);

  const yearMatch = venueYearPart.match(/\b(1[89]\d{2}|20\d{2})\b/);
  const year = yearMatch ? Number(yearMatch[0]) : null;
  const venue = venueYearPart.replace(/,?\s*\b(1[89]\d{2}|20\d{2})\b\s*$/, '').trim();

  return { authors, venue, year: year || null };
}

// Builds one CSL-JSON item from a paper record. Accepts either shape
// already in use across the extension:
//   - "structured" (cite.js search candidates, sourced from Crossref/
//     Semantic Scholar/OpenAlex via background.js — see toResultShape()):
//     { title, authors: [fullName, ...], year, venue, doi, url }
//   - "Scholar-saved" (Collections paper records — see collections.js):
//     { title, authors: "<raw Scholar byline>", url }, with no separate
//     year/venue/doi, parsed via lens81ParseScholarByline() above.
// Every item is typed 'article-journal' regardless of source: nothing in
// this extension reliably distinguishes book/chapter/conference-paper
// from a journal article, and CSL has no generic "unknown" type that
// renders sensibly across all four bundled styles — 'article-journal' is
// the type that degrades most gracefully when the true type is unknown.
function lens81ToCslItem(paper, id) {
  let authors = [];
  let venue = paper.venue || '';
  let year = paper.year || null;

  if (Array.isArray(paper.authors)) {
    authors = paper.authors.map(lens81NameToCslPerson).filter(Boolean);
  } else if (typeof paper.authors === 'string' && paper.authors) {
    if (paper.year || paper.venue) {
      // Structured fields already present elsewhere on the record — this
      // is a plain "Name, Name" list, not a Scholar byline, so just split
      // on commas rather than running byline-specific parsing on text
      // that was never in "- Venue, Year -" form to begin with.
      authors = paper.authors
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .map(lens81NameToCslPerson)
        .filter(Boolean);
    } else {
      const parsed = lens81ParseScholarByline(paper.authors);
      authors = parsed.authors;
      venue = venue || parsed.venue;
      year = year || parsed.year;
    }
  }

  const item = { id: String(id), type: 'article-journal', title: paper.title || 'Untitled' };
  if (authors.length) item.author = authors;
  if (venue) item['container-title'] = venue;
  if (year) item.issued = { 'date-parts': [[year]] };
  if (paper.doi) item.DOI = paper.doi;
  if (paper.url) item.URL = paper.url;
  return item;
}

// citeproc-js emits HTML (<i>italics</i>, <div class="csl-entry">, HTML
// entities, etc.) meant to be rendered directly into a page. Both the Cite
// popover and Collections export want plain text (to copy into a document,
// or write to a .txt/.md file), so this renders the markup through an
// off-DOM element and reads .textContent back — correctly handles entities
// and nested tags in a way hand-rolled tag-stripping regex wouldn't.
function lens81StripCslHtml(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent.trim().replace(/\s+/g, ' ');
}

// --- Public API --------------------------------------------------------

// Formats a single paper as one reference-list entry in the given style.
// Used by the Cite popover (one search candidate at a time).
//
// Each call uses a fresh, never-reused item id. citeproc-js's Engine keeps
// an internal per-id registry across calls (that's how it disambiguates
// names and sorts a real multi-item bibliography) — reusing a fixed id
// like "__single__" for every call caused the *second* call on an
// already-cached engine to silently return the *first* call's cached
// result instead of the new paper's, since citeproc-js saw the same id
// already registered and didn't know its underlying data had changed.
let lens81CslSingleItemCounter = 0;
function lens81FormatCitation(paper, styleKey) {
  return lens81CslEnqueue(async () => {
    const engine = await lens81GetCslEngine(styleKey);
    const id = `__single_${lens81CslSingleItemCounter++}__`;
    lens81CslItemStore = { [id]: lens81ToCslItem(paper, id) };
    engine.updateItems([id]);
    const bib = engine.makeBibliography();
    const html = bib && bib[1] && bib[1][0] ? bib[1][0] : '';
    return lens81StripCslHtml(html);
  });
}

// Formats many papers as one properly-sorted, properly-disambiguated
// bibliography in one pass — the actual advantage of a real CSL engine
// over formatting entries one at a time: citeproc-js handles cross-item
// name disambiguation ("Smith 2020a" / "2020b") and each style's own sort
// order (alphabetical for APA/MLA/Chicago, citation order for IEEE)
// itself, rather than the caller trying to reproduce that logic. Used by
// Collections export ("Formatted citations" format).
//
// Each call uses a fresh batch of ids, for the same reason
// lens81FormatCitation's ids are never reused (see its comment above) —
// positional ids like "item0"/"item1" would otherwise collide with an
// earlier, unrelated bibliography call on the same cached engine (e.g.
// formatting two different collections back to back) and could silently
// serve stale cached entries instead of the new collection's papers.
let lens81CslBatchCounter = 0;
function lens81FormatBibliography(papers, styleKey) {
  return lens81CslEnqueue(async () => {
    const engine = await lens81GetCslEngine(styleKey);
    const batch = lens81CslBatchCounter++;
    const items = {};
    const ids = papers.map((p, i) => {
      const id = `batch${batch}_item${i}`;
      items[id] = lens81ToCslItem(p, id);
      return id;
    });
    lens81CslItemStore = items;
    engine.updateItems(ids);
    const bib = engine.makeBibliography();
    if (!bib || !bib[1]) return [];
    return bib[1].map(lens81StripCslHtml);
  });
}
